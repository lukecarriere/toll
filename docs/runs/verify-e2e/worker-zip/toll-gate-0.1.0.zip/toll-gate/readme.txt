=== Toll Gate ===
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 0.1.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Toll keeps comment forms, logins, and write APIs quiet. Visitors read for free and post without solving anything. Floods take another road.

== Description ==

Toll checks writes, not page views. Leave public pages open so people and answer engines can read you. Turn Toll on for comments, forms, logins, and APIs.

== Changelog ==

= 0.1.0 =
* First release.
